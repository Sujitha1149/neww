<!--owl carousal-->
<script src="js/jquery3.min.lib.js"></script>
<script src="js/owl.carousel.min.js"></script>
<!--Easy ticker-->
<script src="js/jquery.easy-ticker.min.js"></script>
<!--normal js-->
<script src="js/script.js"></script>
</body>

</html>
<!-- ================ Bootstrap ================ -->
<?php 
include_once '../bootstrap.php';
?>
<!-- ================ Navbar style ================ -->
<style>
    <?php include '../style.css' ?>;     
</style>
<!-- ================ CSS FILE ================ -->
<style>
    <?php include 'other.css' ?>;     
</style>

<!-- ================ Navbar ================ -->
<?php
include '../nav/nav.php';
?>

<!-- ================ABOUT RGUKT ================ -->
<div class="vision-mission-bg">
        <h1 class="vision-mission-head">Consultancy</h1>
</div>
<div class="container">
        <div class="row mt-5 mb-5">
            <div class="col-12 mb-5 text-center">
                <h1 class="reve-cont-head">Consultancy</h1>
                <hr class="reve-line ml-auto mr-auto"/>
            </div>
            <div class="col-12 table-responsive">
                <table>
                    <tr>
                        <th>S.NO</th>
                        <th>Name of the Consultant</th>
                        <th>Consulting/Sponsoring Agency with Contact Details</th>
                        <th>Revenue Generated</th>
                        <th>Campus</th>
                    </tr>
                    <tr>
                        <th>1</th>
                        <th>Dr. T. Parthasarathi</th>
                        <th>Consultancy Agreement only received.</th>
                        <th>Kyntox biotech india</th>
                        <th>RGUKT</th>
                    </tr>
                    <tr>
                        <th>2</th>
                        <th>Dr. T. Parthasarathi</th>
                        <th>Consultancy Agreement only received.</th>
                        <th>Kyntox biotech india</th>
                        <th>RGUKT</th>
                    </tr>
                    <tr>
                        <th>3</th>
                        <th>Dr. T. Parthasarathi</th>
                        <th>Consultancy Agreement only received.</th>
                        <th>Kyntox biotech india</th>
                        <th>RGUKT</th>
                    </tr>
                    <tr>
                        <th>4</th>
                        <th>Dr. T. Parthasarathi</th>
                        <th>Consultancy Agreement only received.</th>
                        <th>Kyntox biotech india</th>
                        <th>RGUKT</th>
                    </tr>
                    <tr>
                        <th>5</th>
                        <th>Dr. T. Parthasarathi</th>
                        <th>Consultancy Agreement only received.</th>
                        <th>Kyntox biotech india</th>
                        <th>RGUKT</th>
                    </tr>
                    <tr>
                        <th>6</th>
                        <th>Dr. T. Parthasarathi</th>
                        <th>Consultancy Agreement only received.</th>
                        <th>Kyntox biotech india</th>
                        <th>RGUKT</th>
                    </tr>
                </table>
            </div>
        </div>
    </div>
<!-- ================ footer ================ -->
<?php
include '../footer/footer.php';
?>
<!-- ================ Bootstrap ================ -->
<?php 
include_once '../bootstrap.php';
?>
<!-- ================ Navbar style ================ -->
<style>
    <?php include '../style.css' ?>;     
</style>
<!-- ================ CSS FILE ================ -->
<style>
    <?php include 'alldept.css' ?>;     
</style>

<!-- ================ Navbar ================ -->
<?php
include '../nav.php';
?>

<!-- ================ABOUT RGUKT ================ -->
<div class="vision-mission-bg">
        <h1 class="vision-mission-head">Computer Science & Engineering</h1>
</div>
<div class="container">
    <div class="row mt-5">
    <div class="col-12 col-md-3  d-none d-md-block">
                <ul class="side-bar-quick">
                    <li class="vision-links-head">Quick Links</li>
                    <hr class="quick-links-line" />
                    <li class="menu-item-quick"><a href="instituteinfo.php?data=csedept" class="nav-list-sty">CSE</a></li>
                    <hr class="quick-links-line" />
                    <li class="menu-item-quick"><a href="instituteinfo.php?data=ecedept" class="nav-list-sty">ECE</a></li>
                    <hr class="quick-links-line" />
                    <li class="menu-item-quick"><a href="instituteinfo.php?data=eeedept" class="nav-list-sty">EEE</a></li>
                    <hr class="quick-links-line" />
                    <li class="menu-item-quick"><a href="instituteinfo.php?data=mechdept" class="nav-list-sty">MECH</a></li>
                    <hr class="quick-links-line" />
                    <li class="menu-item-quick"><a href="instituteinfo.php?data=civildept" class="nav-list-sty">CIVIL</a></li>
                    <hr class="quick-links-line" />
                    <li class="menu-item-quick"><a href="instituteinfo.php?data=mmedept" class="nav-list-sty">MME</a></li>
                    <hr class="quick-links-line" />
                    <li class="menu-item-quick"><a href="instituteinfo.php?data=chemicaldept" class="nav-list-sty">CHEMICAL</a></li>
                    
                </ul>
    </div>
    <div class="col-12 col-md-9">
        <h1 class="chanc-about mb-3">Department Of Computer Science & Engineering</h1>
        <p class="chanc-pro-des">Computer Science Engineering (CSE) is an engineering discipline that covers several topics related to computation, programming languages, program design, computer hardware and software and integrates several fields of computer science. It is one of the trending subjects which students pursue after completing Class 12. CSE is a four-year undergraduate course which involves various aspects needed for the creation of a computer system.</p>
        <h1 class="chanc-about mt-3">Vision</h1>
        <p class="chanc-pro-des">To excel in the field of Computer Science and Engineering, to meet the emerging needs of the industry, society and beyond.</p>
        <h1 class="chanc-about mt-3">Mission</h1>
        <ul class="vision-list-type">
                <li class="mission-links-des">
                To impart need based education to meet the requirements of the industry and society.
                </li>
                <li class="mission-links-des">
                To build technologically competent individuals for industry and entrepreneurial ventures by providing infrastructure and human resources.
                </li>
                <li class="mission-links-des">
                To prepare students for higher education and research oriented activities.
            </li>
        </ul>
    </div>
    </div>
    <div class="row mt-4 pb-4 mb-4">
            <div class="col-12">
                <hr/>
                <h1 class="chanc-about mt-4 text-center"> Computer Science & Engineering Faculty</h1>
                <hr class="dept-hor-line mb-4"/>
            </div>
            <div class="col-12 mt-3 mb-3 col-md-4">
                <div class="governing-card">
                    <div class="governing-img-card d-flex flex-row justify-content-center">
                        <img src="images/user-temp.jpg" class="governing-img" />
                    </div>
                    <div>
                        <h1 class="governing-card-head text-center">Bupathi Sampath Babu</h1>
                        <div class="text-center mb-4">
                            <p class="governing-card-des">Head of the Departmet</p>
                            <p class="governing-card-des">Assistant Professor</p>
                            <p class="governing-card-des">sampathbabu@rguktong.ac.in</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 mt-3 mb-3 col-md-4">
                <div class="governing-card">
                    <div class="governing-img-card d-flex flex-row justify-content-center">
                        <img src="images/nagaraj-naik.jpg" class="governing-img" />
                    </div>
                    <div>
                        <h1 class="governing-card-head text-center">Dr.B.Nagaraj Naik</h1>
                        <div class="text-center mb-4">
                            <p class="governing-card-des">Ph.D</p>
                            <p class="governing-card-des">Assistant Professor</p>
                            <p class="governing-card-des">bnn@rguktong.ac.in</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 mt-3 mb-3 col-md-4">
                <div class="governing-card">
                    <div class="governing-img-card d-flex flex-row justify-content-center">
                        <img src="images/mallikarjun.jpg" class="governing-img" />
                    </div>
                    <div>
                        <h1 class="governing-card-head text-center">Mallikarjuna Nandi</h1>
                        <div class="text-center mb-4">
                            <p class="governing-card-des">M.Tech</p>
                            <p class="governing-card-des">Assistant Professor</p>
                            <p class="governing-card-des">man@rguktong.ac.in</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 mt-3 mb-3 col-md-4">
                <div class="governing-card">
                    <div class="governing-img-card d-flex flex-row justify-content-center">
                        <img src="images/vinitha.jpeg" class="governing-img" />
                    </div>
                    <div>
                        <h1 class="governing-card-head text-center"> M.Vinitha</h1>
                        <div class="text-center mb-4">
                            <p class="governing-card-des">M.Tech</p>
                            <p class="governing-card-des">Assistant Professor</p>
                            <p class="governing-card-des">vinitha@rguktong.ac.in</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 mt-3 mb-3 col-md-4">
                <div class="governing-card">
                    <div class="governing-img-card d-flex flex-row justify-content-center">
                        <img src="images/sowmya.jpg" class="governing-img" />
                    </div>
                    <div>
                        <h1 class="governing-card-head text-center">Sowmya .M</h1>
                        <div class="text-center mb-4">
                            <p class="governing-card-des">M.Tech</p>
                            <p class="governing-card-des">Assistant Professor</p>
                            <p class="governing-card-des">sm@rguktong.ac.in</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 mt-3 mb-3 col-md-4">
                <div class="governing-card">
                    <div class="governing-img-card d-flex flex-row justify-content-center">
                        <img src="images/sindhu.jpg" class="governing-img" />
                    </div>
                    <div>
                        <h1 class="governing-card-head text-center">P.Sindhu</h1>
                        <div class="text-center mb-4">
                            <p class="governing-card-des">M.Tech</p>
                            <p class="governing-card-des">Assistant Professor</p>
                            <p class="governing-card-des">sdr@rguktong.ac.in</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 mt-3 mb-3 col-md-4">
                <div class="governing-card">
                    <div class="governing-img-card d-flex flex-row justify-content-center">
                        <img src="images/sireesha.jpg" class="governing-img" />
                    </div>
                    <div>
                        <h1 class="governing-card-head text-center">B.shireesha</h1>
                        <div class="text-center mb-4">
                            <p class="governing-card-des">M.Tech</p>
                            <p class="governing-card-des">Assistant Professor</p>
                            <p class="governing-card-des">bs@rguktong.ac.in</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 mt-3 mb-3 col-md-4">
                <div class="governing-card">
                    <div class="governing-img-card d-flex flex-row justify-content-center">
                        <img src="images/krishna.jpg" class="governing-img" />
                    </div>
                    <div>
                        <h1 class="governing-card-head text-center">Krishna Manam</h1>
                        <div class="text-center mb-4">
                            <p class="governing-card-des">M.Tech</p>
                            <p class="governing-card-des">Assistant Professor</p>
                            <p class="governing-card-des">km@rguktong.ac.in</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 mt-3 mb-3 col-md-4">
                <div class="governing-card">
                    <div class="governing-img-card d-flex flex-row justify-content-center">
                        <img src="images/user-temp.jpg" class="governing-img" />
                    </div>
                    <div>
                        <h1 class="governing-card-head text-center">T. Sreekanth</h1>
                        <div class="text-center mb-4">
                            <p class="governing-card-des">M.Tech</p>
                            <p class="governing-card-des">Assistant Professor</p>
                            <p class="governing-card-des">sreekanth@rguktong.ac.in</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 mt-3 mb-3 col-md-4">
                <div class="governing-card">
                    <div class="governing-img-card d-flex flex-row justify-content-center">
                        <img src="images/madavilatha.jpg" class="governing-img" />
                    </div>
                    <div>
                        <h1 class="governing-card-head text-center">N. Madhavilatha</h1>
                        <div class="text-center mb-4">
                            <p class="governing-card-des">M.Tech</p>
                            <p class="governing-card-des">Assistant Professor</p>
                            <p class="governing-card-des">nmadhavilatha@rguktong.ac.in</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 mt-3 mb-3 col-md-4">
                <div class="governing-card">
                    <div class="governing-img-card d-flex flex-row justify-content-center">
                        <img src="images/user-temp.jpg" class="governing-img" />
                    </div>
                    <div>
                        <h1 class="governing-card-head text-center">Beerala Murali</h1>
                        <div class="text-center mb-4">
                            <p class="governing-card-des">M.Tech</p>
                            <p class="governing-card-des">Assistant Professor</p>
                            <p class="governing-card-des">muralibeerala@rguktong.ac.in</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 mt-3 mb-3 col-md-4">
                <div class="governing-card">
                    <div class="governing-img-card d-flex flex-row justify-content-center">
                        <img src="images/user-temp.jpg" class="governing-img" />
                    </div>
                    <div>
                        <h1 class="governing-card-head text-center">Sikhanam NAgamani</h1>
                        <div class="text-center mb-4">
                            <p class="governing-card-des">M.Tech</p>
                            <p class="governing-card-des">Assistant Professor</p>
                            <p class="governing-card-des">sikhinagamani@rguktong.ac.in</p>
                        </div>
                    </div>
                </div>
            </div>

        </div>
</div>

<!-- ================ footer ================ -->
<?php
include '../footer.php';
?>
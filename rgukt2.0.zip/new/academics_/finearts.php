<!-- ================ Bootstrap ================ -->
<?php 
include_once '../bootstrap.php';
?>
<!-- ================ Navbar style ================ -->
<style>
    <?php include '../style.css' ?>;     
</style>
<!-- ================ CSS FILE ================ -->
<style>
    <?php include 'alldept.css' ?>;     
</style>

<!-- ================ Navbar ================ -->
<?php
include '../nav.php';
?>

<!-- ================ABOUT RGUKT ================ -->
<div class="vision-mission-bg">
        <h1 class="vision-mission-head">Fine Arts Department</h1>
</div>
<div class="container mt-5 mb-5">
        <div class="site-heading text-center">
        
            <h4><span> Department of Fine Arts</span></h4>
            <hr class="dept-hor-line"/>
        </div>
        <div class="row mt-4 pb-4">

        </div>
    </div>

<!-- ================ footer ================ -->
<?php
include '../footer.php';
?>